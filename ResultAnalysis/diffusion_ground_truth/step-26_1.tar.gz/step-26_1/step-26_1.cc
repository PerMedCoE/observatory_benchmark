#include <deal.II/base/utilities.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/base/geometry_info.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/matrix_creator.h>

#include <fstream>
#include <iostream>
#include <vector>
#include <random> // For random number generation

namespace DiffusionProblem
{
  using namespace dealii;

  template <int dim>
  class DiffusionEquation
  {
  public:
    DiffusionEquation();
    void run();

  private:
    void setup_system();
    void solve_time_step();
    void output_results() const;
    void apply_sink_effects();
    void compute_average_concentration() const; // New function to compute averages

    Triangulation<dim> triangulation;
    FE_Q<dim>          fe;
    DoFHandler<dim>    dof_handler;

    AffineConstraints<double> constraints;

    SparsityPattern      sparsity_pattern;
    SparseMatrix<double> mass_matrix;
    SparseMatrix<double> laplace_matrix;
    SparseMatrix<double> system_matrix;

    Vector<double> solution;
    Vector<double> old_solution;
    Vector<double> system_rhs;

    double       time;
    double       time_step;
    unsigned int timestep_number;

    const double theta;
    const double consumption_rate;
    const double diffusion_coefficient;

    std::vector<Point<dim>> sink_points;
  };

  template <int dim>
  class BoundaryConcentration : public Function<dim>
  {
  public:
    BoundaryConcentration() : Function<dim>() {}

    virtual double value(const Point<dim> & /*p*/,
                         const unsigned int /*component*/ = 0) const override
    {
      return 10.0; // Fixed concentration at the boundary set to 10
    }
  };


  template <int dim>
  DiffusionEquation<dim>::DiffusionEquation()
    : fe(1)
    , dof_handler(triangulation)
    , time_step(0.01)  // Set the time step to 0.01 min
    , theta(0.5)
    , consumption_rate(2000.0)
    , diffusion_coefficient(2000.0)
  {
    // Generate 1000 random sink points within the box
    std::mt19937 gen;
    std::uniform_real_distribution<double> dist(0, 240); // Box dimensions

    for (int i = 0; i < 1000; ++i)
      sink_points.push_back(Point<dim>(dist(gen), dist(gen), dist(gen)));
  }

  template <int dim>
  void DiffusionEquation<dim>::setup_system()
  {
    dof_handler.distribute_dofs(fe);

    constraints.clear();
    DoFTools::make_hanging_node_constraints(dof_handler, constraints);
    constraints.close();

    DynamicSparsityPattern dsp(dof_handler.n_dofs());
    DoFTools::make_sparsity_pattern(dof_handler,
                                    dsp,
                                    constraints,
                                    /*keep_constrained_dofs = */ true);
    sparsity_pattern.copy_from(dsp);

    mass_matrix.reinit(sparsity_pattern);
    laplace_matrix.reinit(sparsity_pattern);
    system_matrix.reinit(sparsity_pattern);

    MatrixCreator::create_mass_matrix(dof_handler,
                                      QGauss<dim>(fe.degree + 1),
                                      mass_matrix);
    MatrixCreator::create_laplace_matrix(dof_handler,
                                         QGauss<dim>(fe.degree + 1),
                                         laplace_matrix);

    solution.reinit(dof_handler.n_dofs());
    old_solution.reinit(dof_handler.n_dofs());
    system_rhs.reinit(dof_handler.n_dofs());
  }

  template <int dim>
  void DiffusionEquation<dim>::apply_sink_effects()
  {
    for (const auto &sink_point : sink_points)
    {
      // Find the closest degree of freedom to each sink point
      double min_distance = std::numeric_limits<double>::max();
      unsigned int closest_dof = 0;

      for (const auto &cell : dof_handler.active_cell_iterators())
      {
        for (unsigned int v = 0; v < GeometryInfo<dim>::vertices_per_cell; ++v)
        {
          const unsigned int dof_index = cell->vertex_dof_index(v, 0);
          const double distance = sink_point.distance(cell->vertex(v));
          
          if (distance < min_distance)
          {
            min_distance = distance;
            closest_dof = dof_index;
          }
        }
      }

      // Apply the sink effect by subtracting from the system_rhs vector
      system_rhs[closest_dof] = std::max(0.0, system_rhs[closest_dof]- consumption_rate * time_step);
    }
  }

  template <int dim>
  void DiffusionEquation<dim>::compute_average_concentration() const
  {
    const unsigned int n_subdivisions = 12;
    const double subbox_length = 240.0 / n_subdivisions;

    std::vector<double> subbox_totals(n_subdivisions * n_subdivisions * n_subdivisions, 0.0);
    std::vector<unsigned int> subbox_counts(n_subdivisions * n_subdivisions * n_subdivisions, 0);

    QGauss<dim> quadrature_formula(fe.degree + 1);
    FEValues<dim> fe_values(fe, quadrature_formula, update_values | update_JxW_values);

    for (const auto &cell : dof_handler.active_cell_iterators())
    {
      fe_values.reinit(cell);
      double cell_average = 0.0;

      for (unsigned int q = 0; q < quadrature_formula.size(); ++q)
      {
        //cell_average += fe_values.shape_value(0, q) * fe_values.JxW(q) * solution(cell->vertex_dof_index(0, 0));
        cell_average += fe_values.shape_value(0, q) * solution(cell->vertex_dof_index(0, 0));
      }

      const Point<dim> cell_center = cell->center();
      unsigned int x_idx = std::min(static_cast<unsigned int>(cell_center[0] / subbox_length), n_subdivisions - 1);
      unsigned int y_idx = std::min(static_cast<unsigned int>(cell_center[1] / subbox_length), n_subdivisions - 1);
      unsigned int z_idx = std::min(static_cast<unsigned int>(cell_center[2] / subbox_length), n_subdivisions - 1);

      unsigned int index = x_idx * n_subdivisions * n_subdivisions + y_idx * n_subdivisions + z_idx;

      subbox_totals[index] += cell_average;
      subbox_counts[index]++;
    }

    // Calculate and output average concentrations
    std::ofstream output("average_concentration_" + std::to_string(timestep_number) + ".txt");
    double avgC = 0;
    int avgN = 0;
    for (unsigned int i = 0; i < n_subdivisions; ++i)
    {
      for (unsigned int j = 0; j < n_subdivisions; ++j)
      {
        for (unsigned int k = 0; k < n_subdivisions; ++k)
        {
          unsigned int index = i * n_subdivisions * n_subdivisions + j * n_subdivisions + k;
          double average_concentration = (subbox_counts[index] > 0) ? (subbox_totals[index] / subbox_counts[index]) : 0;
          output << "Subbox (" << i << ", " << j << ", " << k << "): "
                 << average_concentration << std::endl;
	  avgC += average_concentration;
	  avgN += 1;
        }
     }
   }
	avgC /= avgN;
	std::cout << "average concentration: " << avgC << " number: " << avgN << std::endl;
  }

  template <int dim>
  void DiffusionEquation<dim>::solve_time_step()
  {
    SolverControl            solver_control(1000, 1e-8 * system_rhs.l2_norm());
    SolverCG<Vector<double>> cg(solver_control);

    PreconditionSSOR<SparseMatrix<double>> preconditioner;
    preconditioner.initialize(system_matrix, 1.0);

    cg.solve(system_matrix, solution, system_rhs, preconditioner);

    constraints.distribute(solution);

	for (unsigned int i = 0; i < solution.size(); ++i)
		solution[i] = std::max(0.0, solution[i]);
  }

  template <int dim>
  void DiffusionEquation<dim>::output_results() const
  {
    DataOut<dim> data_out;

    data_out.attach_dof_handler(dof_handler);
    data_out.add_data_vector(solution, "Concentration");

    data_out.build_patches();

    const std::string filename =
      "solution-" + Utilities::int_to_string(timestep_number, 3) + ".vtk";
    std::ofstream output(filename);
    data_out.write_vtk(output);
  }

  template <int dim>
  void DiffusionEquation<dim>::run()
  {
    const std::vector<unsigned int> subdivisions = {12, 12, 12};
    const Point<dim> lower_left(0, 0, 0);
    const Point<dim> upper_right(240, 240, 240);
    GridGenerator::subdivided_hyper_rectangle(triangulation, subdivisions, lower_left, upper_right);

	std::cout << "before setup system" << std::endl;
    setup_system();
	std::cout << "after setup system" << std::endl;

    time            = 0.0;
    timestep_number = 0;

    VectorTools::interpolate(dof_handler,
                             Functions::ZeroFunction<dim>(),
                             old_solution);
    solution = old_solution;

	std::cout << "before output result" << std::endl;
    output_results();
	std::cout << "after output result" << std::endl;

    const double end_time = 10.0;  // Total simulation time in minutes
    while (time <= end_time)
    {
      time += time_step;
      ++timestep_number;

	std::cout << "time: " << time << " time step: " << time_step << std::endl;
      mass_matrix.vmult(system_rhs, old_solution);
      laplace_matrix.vmult_add(system_rhs, solution);

      system_matrix.copy_from(mass_matrix);
      system_matrix.add(theta * time_step * diffusion_coefficient, laplace_matrix);

      constraints.condense(system_matrix, system_rhs);

      {
        BoundaryConcentration<dim> boundary_function;
        boundary_function.set_time(time);

        std::map<types::global_dof_index, double> boundary_values;
        VectorTools::interpolate_boundary_values(dof_handler,
                                                 0,//types::boundary_id::all_boundary_ids,
                                                 boundary_function,
                                                 boundary_values);

        MatrixTools::apply_boundary_values(boundary_values,
                                           system_matrix,
                                           solution,
                                           system_rhs);
      }

      apply_sink_effects(); // Apply sink effects at each time step

	std::cout << "before solve time step" << std::endl;
      solve_time_step();
	std::cout << "after solve time step" << std::endl;
      output_results();
	std::cout << "after output result" << std::endl;

      compute_average_concentration(); // Compute average concentration in each subbox
      old_solution = solution;
    }
  }
} // namespace DiffusionProblem


int main()
{
  try
    {
      using namespace DiffusionProblem;

      DiffusionEquation<3> diffusion_solver;
	std::cout << "before solver is run!" << std::endl;
      diffusion_solver.run();
    }
  catch (std::exception &exc)
    {
      std::cerr << "\n----------------------------------------------------\n";
      std::cerr << "Exception on processing: " << exc.what() << std::endl;
      std::cerr << "Aborting!" << std::endl;
      std::cerr << "----------------------------------------------------\n";

      return 1;
    }
  catch (...)
    {
      std::cerr << "\n----------------------------------------------------\n";
      std::cerr << "Unknown exception!" << std::endl;
      std::cerr << "Aborting!" << std::endl;
      std::cerr << "----------------------------------------------------\n";
      return 1;
    }

  return 0;
}
